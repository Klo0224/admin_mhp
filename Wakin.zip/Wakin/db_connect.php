<?php
$servername = "localhost";
$username = "root"; // Change this to your MySQL username
$password = ""; // Leave this empty if you're using the default
$dbname = "phq9_survey";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>