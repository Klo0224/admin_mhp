<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = 1; // Replace with dynamic user ID if applicable
    $answers = [
        'interest1' => $_POST['interest1'] ?? null,
        'interest2' => $_POST['interest2'] ?? null,
        'interest3' => $_POST['interest3'] ?? null,
        'interest4' => $_POST['interest4'] ?? null,
        'interest5' => $_POST['interest5'] ?? null,
        'interest6' => $_POST['interest6'] ?? null,
        'interest7' => $_POST['interest7'] ?? null,
        'interest8' => $_POST['interest8'] ?? null,
        'interest9' => $_POST['interest9'] ?? null,
        'interest10' => $_POST['interest10'] ?? null,
       
    ];

    // Prepare SQL statement
    $stmt = $conn->prepare("INSERT INTO responses (user_id, question_id, answer) VALUES (?, ?, ?)");
    foreach ($answers as $question_id => $answer) {
        if ($answer !== null) {
            $stmt->bind_param("iis", $user_id, $question_id, $answer);
            $stmt->execute();
        }
    }

    // Feedback to the user
    echo "Responses submitted successfully!";
    header("Location: thank_you.php"); // Optionally redirect to a thank you page
    exit();
}

$conn->close();
?>