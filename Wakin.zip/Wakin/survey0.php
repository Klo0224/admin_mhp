<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="PHQ9_Questionnaire.css"> <!-- Link your CSS file -->
    <title>PHQ-9 Survey</title>
</head>
<body>
    <h1>Patient Health Questionnaire</h1>
    <form action="submit_survey.php" method="POST">
        <?php
        include 'db_connect.php';

        // Fetch questions from the database
        $sql = "SELECT * FROM questions";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<label>" . $row['question_text'] . "</label><br>";
                echo "<select name='answer[" . $row['question_id'] . "]'>";
                echo "<option value='Not at all'>Not at all</option>";
                echo "<option value='Several days'>Several days</option>";
                echo "<option value='More than half the days'>More than half the days</option>";
                echo "<option value='Nearly every day'>Nearly every day</option>";
                echo "</select><br><br>";
            }
        } else {
            echo "No questions found.";
        }

        $conn->close();
        ?>
        <input type="submit" value="Submit">
    </form>
</body>
</html>
