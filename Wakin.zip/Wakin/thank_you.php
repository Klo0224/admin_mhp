<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Thank You</title>
</head>
<body>
    <h1>Thank You!</h1>
    <p>Your responses have been recorded successfully. If you need further assistance, please contact us.</p>
</body>
</html>