<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Patient Health Questionnaire</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="PHQ9_Questionnaire.css">
  <script>
        function validateForm(event) {
            const answers = document.querySelectorAll('input[type="radio"]');
            let allAnswered = true;
            
            // Check if each question has been answered
            for (let i = 0; i < answers.length; i++) {
                const questionGroup = answers[i].name;
                const questionAnswers = document.getElementsByName(questionGroup);
                
                // If no radio button is checked for this question, set allAnswered to false
                if (![...questionAnswers].some(radio => radio.checked)) {
                    allAnswered = false;
                    break;
                }
            }

            if (!allAnswered) {
                alert("Please answer all questions before submitting.");
                event.preventDefault(); // Prevent form submission
            }
        }
    </script>
</head>
<body>
        <div class="intro">
      <div class="phq-intro">
        <div class="overlap">
          <div class="overlap">
            <img class="nav-bar" src="img/nav-bar.png" />
            <img class="ellipse" src="img/klowi.png" />
            <div class="text-wrapper">Chloe Kate Realin</div>
            <img class="logout" src="img/logout.png" />
            <img class="logo-MINDSOOTHE" src="img/logo-mindsoothe-1.png" />
            <div class="search-bar">
              <div class="group">
                <div class="overlap-group-wrapper">
                  <div class="overlap-group">
                    <div class="div">Search Mindsoothe</div>
                    <img class="search-ICON" src="img/search.png" />
                  </div>
                </div>
              </div>
            </div>
            <p class="mental-wellness">
              <span class="span">Mental Wellness</span> <span class="text-wrapper-2"> Companion</span>
            </p>
            <div class="mini-side-bar">
              <img class="frame" src="img/frame-3.svg" /> <img class="mini" src="img/mini.png" />
            </div>
            <div class="date-picker">
              <div class="base-calendar">
                <div class="date-header">
                  <img class="chevron" src="img/chevron-8.svg" />
                  <div class="div-2">
                    <div class="december-wrapper"><div class="december">May</div></div>
                    <div class="div-2"><div class="element">2024</div></div>
                  </div>
                  <img class="chevron" src="img/chevron-9.svg" />
                </div>
                <div class="frame-2">
                  <div class="frame-3">
                    <div class="work-day"><div class="th">Sun</div></div>
                    <div class="work-day"><div class="th-2">Mon</div></div>
                    <div class="work-day"><div class="th-2">Tue</div></div>
                    <div class="work-day"><div class="th-2">Wed</div></div>
                    <div class="work-day"><div class="th-2">Thu</div></div>
                    <div class="work-day"><div class="th-2">Fri</div></div>
                    <div class="work-day"><div class="th">Sat</div></div>
                  </div>
                  <div class="frame-2">
                    <div class="frame-3">
                      <div class="calendar-date"></div>
                      <div class="calendar-date"></div>
                      <div class="calendar-date"></div>
                      <div class="calendar-date"></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">1</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">2</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">3</div></div>
                    </div>
                    <div class="frame-3">
                      <div class="calendar-date-2"><div class="element-2">4</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">5</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">6</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">7</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">8</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">9</div></div>
                      <div class="calendar-date-2"><div class="element-2">10</div></div>
                    </div>
                    <div class="frame-3">
                      <div class="calendar-date-2"><div class="element-2">11</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">23</div></div>
                      <div class="calendar-date-2">
                        <div class="text-wrapper-3">13</div>
                        <div class="ellipse-2"></div>
                      </div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">14</div></div>
                      <div class="element-wrapper"><div class="element-3">15</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">16</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">17</div></div>
                    </div>
                    <div class="frame-3">
                      <div class="calendar-date-2"><div class="text-wrapper-3">18</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">19</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">20</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-3">21</div></div>
                      <div class="calendar-date-3">
                        <div class="text-wrapper-4">22</div>
                        <div class="ellipse-3"></div>
                      </div>
                      <div class="calendar-date-2"><div class="text-wrapper-4">23</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-4">24</div></div>
                    </div>
                    <div class="frame-3">
                      <div class="calendar-date-2"><div class="text-wrapper-4">25</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-4">26</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-4">27</div></div>
                      <div class="calendar-date-2"><div class="text-wrapper-4">28</div></div>
                      <div class="calendar-date-4">
                        <div class="text-wrapper-4">29</div>
                        <div class="ellipse-4"></div>
                      </div>
                      <div class="div-wrapper"><div class="text-wrapper-4">30</div></div>
                      <div class="calendar-date"></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="overlap-2">
            <div class="frame-4">
              <img class="subs-free-card" src="img/subs-free-card-4.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="dr-pic" src="img/dr-pic-2.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Janine Karla</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-11">
              <img class="subs-free-card" src="img/subs-free-card-5.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-12">
              <img class="subs-free-card" src="img/subs-free-card-6.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-13">
              <img class="subs-free-card" src="img/subs-free-card-7.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-14">
              <img class="subs-free-card" src="img/subs-free-card-8.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="dr-pic" src="img/dr-pic-2.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Janine Karla</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-15">
              <img class="subs-free-card" src="img/subs-free-card-9.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-16">
              <img class="subs-free-card" src="img/subs-free-card-10.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="dr-pic" src="img/dr-pic-2.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Janine Karla</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-17">
              <img class="subs-free-card" src="img/subs-free-card-11.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-18">
              <img class="subs-free-card" src="img/subs-free-card-12.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-19">
              <img class="subs-free-card" src="img/subs-free-card-13.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-20">
              <img class="subs-free-card" src="img/subs-free-card-14.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            <div class="frame-21">
              <img class="subs-free-card" src="img/subs-free-card-15.svg" />
              <div class="frame-5">
                <div class="frame-6">
                  <div class="frame-7">
                    <img class="image" src="img/image-23.png" />
                    <div class="frame-8">
                      <div class="text-wrapper-5">Jeanne Denise</div>
                      <div class="licensed-mental">Licensed Mental Health Counselor</div>
                      <div class="text-wrapper-6">9 years of experience</div>
                    </div>
                  </div>
                  <div class="frame-7">
                    <div class="frame-9"><div class="text-wrapper-7">Stress</div></div>
                    <div class="frame-9"><div class="text-wrapper-7">Anxiety</div></div>
                    <div class="frame-9"><div class="text-wrapper-8">Depression</div></div>
                  </div>
                </div>
                <div class="frame-10"><div class="text-wrapper-9">View Profile</div></div>
              </div>
            </div>
            </div>
            <div class="overlap-wrapper">
              <div class="overlap-3">
                <p class="instructions-for">
                  <br>
                  <br>
                  <span class="text-wrapper-10">Instructions for Completing the PHQ-9 Questionnaire</span>
                  <span class="text-wrapper-11">
                    <br>
                    <br>1. Answer Each Question: For each question, mark how often you have <br />experienced each issue in
                    the last two weeks:<br>• Not at all<br>• Several
                    days<br>• More than half the days<br>• Nearly every day<br /><br>2.
                    Question 10: Indicate how difficult these problems have made it to do<br />your work, take care of
                    things at home, or get along with others:<br>• Not difficult at
                    all<br>• Somewhat difficult<br>• Very
                    difficult<br>• Extremely difficult<br /><br>3. Seek Help if Needed: If you have
                    thoughts of self-harm (question 9),<br />please talk to a healthcare professional immediately.</span>
                </p>
                <p class="patient-health">
                  <span class="span">Patient </span>
                  <span class="text-wrapper-2">Health</span>
                  <span class="span">Questionnaire</span>
                </p>
                <div class="start-btn">
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal1">
                    Start
                  </button>
                </div>         
              </div>
            </div>
          </div>
          <img class="chat" src="img/chat.png" />
          <div class="friends">
            <div class="frame-22">
              <div class="frame-23">
                <div class="text-wrapper-13">Friends</div>
                <img class="line" src="img/line-15.svg" />
              </div>
            </div>
            <div class="frame-wrapper">
              <div class="frame-24">
                <div class="frame-25">
                  <img class="img" src="img/gabeitch.png" />
                  <div class="text-wrapper-14">Gabe Itch</div>
                </div>
                <div class="frame-25">
                  <img class="img" src="img/dinalega.png" />
                  <div class="text-wrapper-14">Dina Lega</div>
                </div>
                <div class="frame-25">
                  <img class="eeccf-fbb-b" src="img/dems.png" />
                  <div class="text-wrapper-14">Denise Jeanne</div>
                </div>
                <div class="frame-25">
                  <img class="img" src="img/carlos.png" />
                  <div class="text-wrapper-14">Carlos Joaquin</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <img class="rectangle" src="img/rectangle-60.png" />
      </div>
    </div>
  <!-- Modal Trigger -->
  <div class="container text-center mt-5">
  </div>

  <!-- Modal -->
  <div class="modal" id="modal1" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
            <div class="mb-4">
              <h6>1. Little interest or pleasure in doing things</h6>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest1" id="notAtAll1" value="notAtAll">
                <label class="form-check-label" for="notAtAll1">
                  Not at all
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest1" id="severalDays1" value="severalDays">
                <label class="form-check-label" for="severalDays1">
                  Several days
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest1" id="moreThanHalf1" value="moreThanHalf">
                <label class="form-check-label" for="moreThanHalf1">
                  More than half the day
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest1" id="nearlyEveryday1" value="nearlyEveryday">
                <label class="form-check-label" for="nearlyEveryday1">
                  Nearly every day
                </label>
              </div>
            </div>
            <div class="d-flex justify-content-between">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Previous</button>
              <div class="next-btn">
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal2">Next</button>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal" id="modal2" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
            <div class="mb-4">
              <h6>2. Feeling down, depressed, or hopeless</h6>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest2" id="notAtAll2" value="notAtAll">
                <label class="form-check-label" for="notAtAll2">
                  Not at all
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest2" id="severalDays2" value="severalDays">
                <label class="form-check-label" for="severalDays2">
                  Several days
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest2" id="moreThanHalf2" value="moreThanHalf">
                <label class="form-check-label" for="moreThanHalf2">
                  More than half the day
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest2" id="nearlyEveryday2" value="nearlyEveryday">
                <label class="form-check-label" for="nearlyEveryday2">
                  Nearly every day
                </label>
              </div>
            </div>
            <div class="d-flex justify-content-between">
              <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal1">Previous</button>
              <div class="next-btn">
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal3">Next</button>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <div class="modal" id="modal3" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
        <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
            <div class="mb-4">
              <h6>3. Trouble falling or staying asleep, or sleeping too much</h6>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest3" id="notAtAll3" value="notAtAll">
                <label class="form-check-label" for="notAtAll3">
                  Not at all
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest3" id="severalDays3" value="severalDays">
                <label class="form-check-label" for="severalDays3">
                  Several days
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest3" id="moreThanHalf3" value="moreThanHalf">
                <label class="form-check-label" for="moreThanHalf3">
                  More than half the day
                </label>
              </div>
              <div class="form-check">
                <input class="form-check-input" type="radio" name="interest3" id="nearlyEveryday3" value="nearlyEveryday">
                <label class="form-check-label" for="nearlyEveryday3">
                  Nearly every day
                </label>
              </div>
            </div>
            <div class="d-flex justify-content-between">
              <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal2">Previous</button>
              <div class="next-btn3">
                <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal4">Next</button>
            </div>
          </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<div class="modal" id="modal4" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
          <div class="mb-4">
            <h6>4. Feeling tired or having little energy</h6>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest4" id="notAtAll4" value="notAtAll">
              <label class="form-check-label" for="notAtAll4">
                Not at all
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest4" id="severalDays4" value="severalDays">
              <label class="form-check-label" for="severalDays4">
                Several days
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest4" id="moreThanHalf4" value="moreThanHalf">
              <label class="form-check-label" for="moreThanHalf4">
                More than half the day
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest4" id="nearlyEveryday4" value="nearlyEveryday">
              <label class="form-check-label" for="nearlyEveryday4">
                Nearly every day
              </label>
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal3">Previous</button>
            <div class="next-btn">
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal5">Next</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="modal5" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
          <div class="mb-4">
            <h6>5. Feeling tired or having little energy</h6>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest5" id="notAtAll5" value="notAtAll">
              <label class="form-check-label" for="notAtAll5">
                Not at all
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest5" id="severalDays5" value="severalDays">
              <label class="form-check-label" for="severalDays5">
                Several days
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest5" id="moreThanHalf5" value="moreThanHalf">
              <label class="form-check-label" for="moreThanHalf5">
                More than half the day
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest5" id="nearlyEveryday5" value="nearlyEveryday">
              <label class="form-check-label" for="nearlyEveryday5">
                Nearly every day
              </label>
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal4">Previous</button>
            <div class="next-btn">
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal6">Next</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="modal6" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
          <div class="mb-4">
            <h6>6. Feeling tired or having little energy</h6>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest6" id="notAtAll6" value="notAtAll">
              <label class="form-check-label" for="notAtAll6">
                Not at all
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest6" id="severalDays6" value="severalDays">
              <label class="form-check-label" for="severalDays6">
                Several days
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest6" id="moreThanHalf6" value="moreThanHalf">
              <label class="form-check-label" for="moreThanHalf6">
                More than half the day
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest6" id="nearlyEveryday6" value="nearlyEveryday">
              <label class="form-check-label" for="nearlyEveryday6">
                Nearly every day
              </label>
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal5">Previous</button>
            <div class="next-btn">
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal7">Next</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="modal7" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
          <div class="mb-4">
            <h6>7. Feeling tired or having little energy</h6>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest7" id="notAtAll7" value="notAtAll">
              <label class="form-check-label" for="notAtAll7">
                Not at all
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest7" id="severalDays7" value="severalDays">
              <label class="form-check-label" for="severalDays7">
                Several days
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest7" id="moreThanHalf7" value="moreThanHalf">
              <label class="form-check-label" for="moreThanHalf7">
                More than half the day
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest7" id="nearlyEveryday7" value="nearlyEveryday">
              <label class="form-check-label" for="nearlyEveryday7">
                Nearly every day
              </label>
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal6">Previous</button>
            <div class="next-btn">
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal8">Next</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="modal8" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
          <div class="mb-4">
            <h6>8. Feeling tired or having little energy</h6>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest8" id="notAtAll8" value="notAtAll">
              <label class="form-check-label" for="notAtAll8">
                Not at all
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest8" id="severalDays8" value="severalDays">
              <label class="form-check-label" for="severalDays8">
                Several days
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest8" id="moreThanHalf8" value="moreThanHalf">
              <label class="form-check-label" for="moreThanHalf8">
                More than half the day
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest8" id="nearlyEveryday8" value="nearlyEveryday">
              <label class="form-check-label" for="nearlyEveryday8">
                Nearly every day
              </label>
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal7">Previous</button>
            <div class="next-btn">
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal9">Next</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="modal9" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
          <div class="mb-4">
            <h6>9. Feeling tired or having little energy</h6>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest9" id="notAtAll9" value="notAtAll">
              <label class="form-check-label" for="notAtAll9">
                Not at all
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest9" id="severalDays9" value="severalDays">
              <label class="form-check-label" for="severalDays9">
                Several days
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest9" id="moreThanHalf9" value="moreThanHalf">
              <label class="form-check-label" for="moreThanHalf9">
                More than half the day
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest9" id="nearlyEveryday9" value="nearlyEveryday">
              <label class="form-check-label" for="nearlyEveryday9">
                Nearly every day
              </label>
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal8">Previous</button>
            <div class="next-btn">
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal10">Next</button>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="modal" id="modal10" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalLabel"><strong>Patient <span class="text-wrapper-15">Health</span> Questionnaire</strong></h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="submit_survey.php" method="POST"> <!-- Point to the form submission script -->
          <div class="mb-4">
            <h6>10. Feeling tired or having little energy</h6>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest10" id="notAtAll10" value="notAtAll">
              <label class="form-check-label" for="notAtAll10">
                Not at all
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest10" id="severalDays10" value="severalDays">
              <label class="form-check-label" for="severalDays10">
                Several days
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest10" id="moreThanHalf10" value="moreThanHalf">
              <label class="form-check-label" for="moreThanHalf10">
                More than half the day
              </label>
            </div>
            <div class="form-check">
              <input class="form-check-input" type="radio" name="interest10" id="nearlyEveryday10" value="nearlyEveryday">
              <label class="form-check-label" for="nearlyEveryday10">
                Nearly every day
              </label>
            </div>
          </div>
          <div class="d-flex justify-content-between">
            <button type="button" class="btn btn-secondary" data-bs-toggle="modal" data-bs-target="#modal9">Previous</button>
            <div class="next-btn">
              <button type="button" class="btn" data-bs-toggle="modal" data-bs-target="#modal-body">Submit</button>
              <div class="modal" id="finalModal" tabindex="-1" aria-labelledby="modalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalLabel"><strong>Submit Your Responses</strong></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h6>Are you sure you want to submit your responses?</h6>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Submit</button> <!-- Submit button -->
                </div>
            </div>
        </div>
    </div>
</form>
          </div>
        </div>
        </form>
      </div>
    </div>
  </div>
</div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>