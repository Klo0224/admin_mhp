CREATE DATABASE phq9_survey;
USE phq9_survey;

CREATE TABLE questions (
    question_id INT AUTO_INCREMENT PRIMARY KEY,
    question_text VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

INSERT INTO questions (question_text)
VALUES
('Little interest or pleasure in doing things?'),
('Feeling down, depressed, or hopeless?'),
('Trouble falling or staying asleep, or sleeping too much?'),
('Feeling tired or having little energy?'),
('Poor appetite or overeating?'),
('Feeling bad about yourself—or that you are a failure or have let yourself or your family down?'),
('Trouble concentrating on things, such as reading the newspaper or watching television?'),
('Moving or speaking so slowly that other people could have noticed? Or the opposite—being so fidgety or restless that you have been moving around a lot more than usual?'),
('Thoughts that you would be better off dead or of hurting yourself in some way?'),
('If you checked off any problems, how difficult have these problems made it for you to do your work, take care of things at home, or get along with other people?');

CREATE TABLE responses (
    response_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    question_id INT NOT NULL,
    answer ENUM('Not at all', 'Several days', 'More than half the days', 'Nearly every day') NOT NULL,
    response_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (question_id) REFERENCES questions(question_id) ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    email VARCHAR(100)
);

INSERT INTO responses (user_id, question_id, answer)
VALUES
(1, 1, 'Nearly every day'),
(1, 2, 'Several days'),
(1, 3, 'More than half the days'),
(1, 4, 'Not at all');

SELECT q.question_text as 'Patient Health Questionnaire', r.answer as 'Answer'
FROM responses r
JOIN questions q ON r.question_id = q.question_id
WHERE r.user_id = 1;