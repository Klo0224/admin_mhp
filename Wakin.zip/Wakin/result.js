// Function to open modal
var modal = document.getElementById("resultModal");
var btn = document.getElementById("openModalBtn");
var span = document.getElementsByClassName("close")[0];

btn.onclick = function() {
    modal.style.display = "block";
    calculateResults(); // Call the function to calculate PHQ-9 results
}

span.onclick = function() {
    modal.style.display = "none";
}

window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none"// Function to open modal
        var modal = document.getElementById("resultModal");
        var btn = document.getElementById("openModalBtn");
        var span = document.getElementsByClassName("close")[0];
        
        btn.onclick = function() {
            modal.style.display = "block";
            calculateResults(); // Call the function to calculate PHQ-9 results
        }
        
        span.onclick = function() {
            modal.style.display = "none";
        }
        
        window.onclick = function(event) {
            if (event.target == modal) {
                modal.style.display = "none";
            }
        }
        
        // Function to calculate PHQ-9 results
        function calculateResults() {
            // Replace this array with the actual responses from the PHQ-9 questionnaire
            const answers = [0, 1, 2, 3, 2, 1, 2, 3, 2]; // Example PHQ-9 responses (0–3 scale)
        
            // Calculate total score
            let totalScore = answers.reduce((a, b) => a + b, 0);
            document.getElementById('totalScore').innerText = totalScore;
        
            // Determine depression level based on total score (according to provided classification)
            let depressionLevel = '';
            if (totalScore <= 4) {
                depressionLevel = 'Minimal depression';
            } else if (totalScore >= 5 && totalScore <= 9) {
                depressionLevel = 'Mild depression';
            } else if (totalScore >= 10 && totalScore <= 14) {
                depressionLevel = 'Moderate depression';
            } else if (totalScore >= 15 && totalScore <= 19) {
                depressionLevel = 'Moderately severe depression';
            } else if (totalScore >= 20) {
                depressionLevel = 'Severe depression';
            }
        
            // Update the DOM with the depression level
            document.getElementById('depressionLevel').innerText = depressionLevel;
        
            // Initialize summary counts
            const summary = {
                notAtAll: 0,
                severalDays: 0,
                moreThanHalfDays: 0,
                nearlyEveryDay: 0
            };
        
            // Count how many times each response was selected
            answers.forEach(answer => {
                if (answer === 0) summary.notAtAll++;
                else if (answer === 1) summary.severalDays++;
                else if (answer === 2) summary.moreThanHalfDays++;
                else if (answer === 3) summary.nearlyEveryDay++;
            });
        
            // Display the summary counts
            document.getElementById('notAtAllCount').innerText = summary.notAtAll;
            document.getElementById('severalDaysCount').innerText = summary.severalDays;
            document.getElementById('halfDaysCount').innerText = summary.moreThanHalfDays;
            document.getElementById('nearlyEveryDayCount').innerText = summary.nearlyEveryDay;
        
            // Ensure total score is consistent with the summary count
            let recalculatedTotalScore = summary.severalDays + (summary.moreThanHalfDays * 2) + (summary.nearlyEveryDay * 3);
            if (totalScore !== recalculatedTotalScore) {
                alert('Total score and summary counts do not match!');
            }
        }
        ;
    }
}

// Function to calculate PHQ-9 results (Dummy logic for now)
function calculateResults() {
    // Dummy data, you can replace this with actual answers
    const answers = [0, 1, 2, 3, 2, 1, 2, 3, 2]; // PHQ-9 responses

    let totalScore = answers.reduce((a, b) => a + b, 0);
    document.getElementById('totalScore').innerText = totalScore;

    // Categorizing depression level
    let depressionLevel = '';
    if (totalScore <= 4) depressionLevel = 'Minimal depression';
    else if (totalScore <= 9) depressionLevel = 'Mild depression';
    else if (totalScore <= 14) depressionLevel = 'Moderate depression';
    else if (totalScore <= 19) depressionLevel = 'Moderately severe depression';
    else depressionLevel = 'Severe depression';

    document.getElementById('depressionLevel').innerText = depressionLevel;

    // Counting the summary
    const summary = {
        notAtAll: 0,
        severalDays: 0,
        moreThanHalfDays: 0,
        nearlyEveryDay: 0
    };

    answers.forEach(answer => {
        if (answer === 0) summary.notAtAll++;
        if (answer === 1) summary.severalDays++;
        if (answer === 2) summary.moreThanHalfDays++;
        if (answer === 3) summary.nearlyEveryDay++;
    });

    document.getElementById('notAtAllCount').innerText = summary.notAtAll;
    document.getElementById('severalDaysCount').innerText = summary.severalDays;
    document.getElementById('halfDaysCount').innerText = summary.moreThanHalfDays;
    document.getElementById('nearlyEveryDayCount').innerText = summary.nearlyEveryDay;
}